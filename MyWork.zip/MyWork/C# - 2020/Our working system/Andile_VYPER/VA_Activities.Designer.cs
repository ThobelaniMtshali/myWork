﻿namespace Andile_VYPER
{
    partial class VA_Activities
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblVehiclePlate = new System.Windows.Forms.Label();
            this.lblVehicleName = new System.Windows.Forms.Label();
            this.lblVehicleState = new System.Windows.Forms.Label();
            this.lblHeading = new System.Windows.Forms.Label();
            this.txtVehiclePlate = new System.Windows.Forms.TextBox();
            this.txtVehicleName = new System.Windows.Forms.TextBox();
            this.cbVehicle = new System.Windows.Forms.ComboBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblVehiclePlate
            // 
            this.lblVehiclePlate.AutoSize = true;
            this.lblVehiclePlate.Location = new System.Drawing.Point(183, 78);
            this.lblVehiclePlate.Name = "lblVehiclePlate";
            this.lblVehiclePlate.Size = new System.Drawing.Size(71, 13);
            this.lblVehiclePlate.TabIndex = 0;
            this.lblVehiclePlate.Text = "Number Plate";
            // 
            // lblVehicleName
            // 
            this.lblVehicleName.AutoSize = true;
            this.lblVehicleName.Location = new System.Drawing.Point(183, 120);
            this.lblVehicleName.Name = "lblVehicleName";
            this.lblVehicleName.Size = new System.Drawing.Size(35, 13);
            this.lblVehicleName.TabIndex = 1;
            this.lblVehicleName.Text = "Name";
            // 
            // lblVehicleState
            // 
            this.lblVehicleState.AutoSize = true;
            this.lblVehicleState.Location = new System.Drawing.Point(183, 161);
            this.lblVehicleState.Name = "lblVehicleState";
            this.lblVehicleState.Size = new System.Drawing.Size(29, 13);
            this.lblVehicleState.TabIndex = 2;
            this.lblVehicleState.Text = "Sate";
            // 
            // lblHeading
            // 
            this.lblHeading.AutoSize = true;
            this.lblHeading.Font = new System.Drawing.Font("Modern No. 20", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeading.Location = new System.Drawing.Point(230, 9);
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.Size = new System.Drawing.Size(169, 50);
            this.lblHeading.TabIndex = 3;
            this.lblHeading.Text = "Vehicel";
            // 
            // txtVehiclePlate
            // 
            this.txtVehiclePlate.Location = new System.Drawing.Point(260, 71);
            this.txtVehiclePlate.Name = "txtVehiclePlate";
            this.txtVehiclePlate.Size = new System.Drawing.Size(169, 20);
            this.txtVehiclePlate.TabIndex = 4;
            // 
            // txtVehicleName
            // 
            this.txtVehicleName.Location = new System.Drawing.Point(260, 113);
            this.txtVehicleName.Name = "txtVehicleName";
            this.txtVehicleName.Size = new System.Drawing.Size(169, 20);
            this.txtVehicleName.TabIndex = 5;
            // 
            // cbVehicle
            // 
            this.cbVehicle.FormattingEnabled = true;
            this.cbVehicle.Items.AddRange(new object[] {
            "Needs Service",
            "Serviced"});
            this.cbVehicle.Location = new System.Drawing.Point(260, 152);
            this.cbVehicle.Name = "cbVehicle";
            this.cbVehicle.Size = new System.Drawing.Size(169, 21);
            this.cbVehicle.TabIndex = 6;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(260, 196);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 7;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(354, 196);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 8;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // VA_Activities
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.cbVehicle);
            this.Controls.Add(this.txtVehicleName);
            this.Controls.Add(this.txtVehiclePlate);
            this.Controls.Add(this.lblHeading);
            this.Controls.Add(this.lblVehicleState);
            this.Controls.Add(this.lblVehicleName);
            this.Controls.Add(this.lblVehiclePlate);
            this.Name = "VA_Activities";
            this.Text = "VA_Activities";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblVehiclePlate;
        private System.Windows.Forms.Label lblVehicleName;
        private System.Windows.Forms.Label lblVehicleState;
        private System.Windows.Forms.Label lblHeading;
        private System.Windows.Forms.TextBox txtVehiclePlate;
        private System.Windows.Forms.TextBox txtVehicleName;
        private System.Windows.Forms.ComboBox cbVehicle;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnExit;
    }
}