﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Andile_VYPER
{
    public partial class TSM_Activities : Form
    {
        public TSM_Activities()
        {
            InitializeComponent();
        }

        private void btnProcced_Click(object sender, EventArgs e)
        {
            if(rdbEmployee.Checked)
            {
                this.Hide();

                Employee myEmp = new Employee();

                myEmp.Show();
            }
            else if(rdbMachine.Checked)
            {
                this.Hide();

                Machine myMachine = new Machine();

                myMachine.Show();
            }
        }
    }
}
