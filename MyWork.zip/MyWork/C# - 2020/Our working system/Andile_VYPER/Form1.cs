﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Andile_VYPER
{
    public partial class Welcome : Form
    {
        public Welcome()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnProcced_Click(object sender, EventArgs e)
        {
            if(rdbOfficeManagement.Checked)
            {
                this.Hide();

                Office myOffice = new Office();

                myOffice.Show();
            }
            else if(rdbRegularEmployee.Checked)
            {
                this.Hide();

                Regular myRegular = new Regular();

                myRegular.Show();
            }
        }
    }
}
