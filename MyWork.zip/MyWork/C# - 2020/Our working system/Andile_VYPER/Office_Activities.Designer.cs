﻿namespace Andile_VYPER
{
    partial class Office_Activities
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblHeading = new System.Windows.Forms.Label();
            this.rdbVA_Acticities = new System.Windows.Forms.RadioButton();
            this.rdbTPM_Activities = new System.Windows.Forms.RadioButton();
            this.rdbTSM_Activities = new System.Windows.Forms.RadioButton();
            this.rdbSM_Activities = new System.Windows.Forms.RadioButton();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblHeading
            // 
            this.lblHeading.AutoSize = true;
            this.lblHeading.Font = new System.Drawing.Font("Modern No. 20", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeading.Location = new System.Drawing.Point(320, 24);
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.Size = new System.Drawing.Size(139, 50);
            this.lblHeading.TabIndex = 0;
            this.lblHeading.Text = "Office";
            // 
            // rdbVA_Acticities
            // 
            this.rdbVA_Acticities.AutoSize = true;
            this.rdbVA_Acticities.Location = new System.Drawing.Point(263, 106);
            this.rdbVA_Acticities.Name = "rdbVA_Acticities";
            this.rdbVA_Acticities.Size = new System.Drawing.Size(60, 17);
            this.rdbVA_Acticities.TabIndex = 1;
            this.rdbVA_Acticities.TabStop = true;
            this.rdbVA_Acticities.Text = "Vehicle";
            this.rdbVA_Acticities.UseVisualStyleBackColor = true;
            // 
            // rdbTPM_Activities
            // 
            this.rdbTPM_Activities.AutoSize = true;
            this.rdbTPM_Activities.Location = new System.Drawing.Point(329, 106);
            this.rdbTPM_Activities.Name = "rdbTPM_Activities";
            this.rdbTPM_Activities.Size = new System.Drawing.Size(43, 17);
            this.rdbTPM_Activities.TabIndex = 2;
            this.rdbTPM_Activities.TabStop = true;
            this.rdbTPM_Activities.Text = "Trip";
            this.rdbTPM_Activities.UseVisualStyleBackColor = true;
            // 
            // rdbTSM_Activities
            // 
            this.rdbTSM_Activities.AutoSize = true;
            this.rdbTSM_Activities.Location = new System.Drawing.Point(378, 106);
            this.rdbTSM_Activities.Name = "rdbTSM_Activities";
            this.rdbTSM_Activities.Size = new System.Drawing.Size(84, 17);
            this.rdbTSM_Activities.TabIndex = 3;
            this.rdbTSM_Activities.TabStop = true;
            this.rdbTSM_Activities.Text = "Times Sheet";
            this.rdbTSM_Activities.UseVisualStyleBackColor = true;
            // 
            // rdbSM_Activities
            // 
            this.rdbSM_Activities.AutoSize = true;
            this.rdbSM_Activities.Location = new System.Drawing.Point(468, 106);
            this.rdbSM_Activities.Name = "rdbSM_Activities";
            this.rdbSM_Activities.Size = new System.Drawing.Size(61, 17);
            this.rdbSM_Activities.TabIndex = 4;
            this.rdbSM_Activities.TabStop = true;
            this.rdbSM_Activities.Text = "Service";
            this.rdbSM_Activities.UseVisualStyleBackColor = true;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(297, 160);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 5;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(378, 160);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 6;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            // 
            // Office_Activities
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.rdbSM_Activities);
            this.Controls.Add(this.rdbTSM_Activities);
            this.Controls.Add(this.rdbTPM_Activities);
            this.Controls.Add(this.rdbVA_Acticities);
            this.Controls.Add(this.lblHeading);
            this.Name = "Office_Activities";
            this.Text = "Office_Activities";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblHeading;
        private System.Windows.Forms.RadioButton rdbVA_Acticities;
        private System.Windows.Forms.RadioButton rdbTPM_Activities;
        private System.Windows.Forms.RadioButton rdbTSM_Activities;
        private System.Windows.Forms.RadioButton rdbSM_Activities;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnExit;
    }
}