﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Andile_VYPER
{
    public partial class RegisterVehicleAdmin : Form
    {
        SqlConnection connecting = new SqlConnection(@"Data Source=STHE-ONP63U3\MSSQLSERVER01;Initial Catalog=WILL;Integrated Security=True");
        public RegisterVehicleAdmin()
        {
            InitializeComponent();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            try 
            {
                connecting.Open();
                string query = "INSERT INTO VEHICLE_ADMIN VALUES('" + txtUserName.Text + "','" + txtPassword.Text + "')";

                SqlCommand cmd = new SqlCommand(query, connecting);

                cmd.ExecuteNonQuery();

                connecting.Close();

                VehicleAdmin myVehicelAdmin = new VehicleAdmin();

                myVehicelAdmin.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            this.Hide();
            VehicleAdmin VA = new VehicleAdmin();
            VA.Show();
        }
    }
}
