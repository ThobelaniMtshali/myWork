﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Andile_VYPER
{
    public partial class RegisterTripManager : Form
    {
        SqlConnection connecting = new SqlConnection(@"Data Source=DESKTOP-NKOPO69\SQLEXPRESS;Initial Catalog=WILL;Integrated Security=True");
        public RegisterTripManager()
        {
            InitializeComponent();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            try
            {
                connecting.Open();
                string query = "INSERT INTO TRIP_MANAGER VALUES('" + txtUserName.Text + "','" + txtPassword.Text + "')";

                SqlCommand cmd = new SqlCommand(query, connecting);

                cmd.ExecuteNonQuery();

                connecting.Close();

                TripManager myTrip = new TripManager();

                myTrip.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            this.Hide();
            TripManager TPM = new TripManager();
            TPM.Show();
        }
    }
}
