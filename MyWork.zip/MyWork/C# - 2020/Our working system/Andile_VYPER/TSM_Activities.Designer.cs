﻿namespace Andile_VYPER
{
    partial class TSM_Activities
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblHeading = new System.Windows.Forms.Label();
            this.rdbEmployee = new System.Windows.Forms.RadioButton();
            this.rdbMachine = new System.Windows.Forms.RadioButton();
            this.btnProcced = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblHeading
            // 
            this.lblHeading.AutoSize = true;
            this.lblHeading.Font = new System.Drawing.Font("Modern No. 20", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeading.Location = new System.Drawing.Point(260, 37);
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.Size = new System.Drawing.Size(238, 50);
            this.lblHeading.TabIndex = 0;
            this.lblHeading.Text = "Time Sheet";
            // 
            // rdbEmployee
            // 
            this.rdbEmployee.AutoSize = true;
            this.rdbEmployee.Location = new System.Drawing.Point(269, 133);
            this.rdbEmployee.Name = "rdbEmployee";
            this.rdbEmployee.Size = new System.Drawing.Size(71, 17);
            this.rdbEmployee.TabIndex = 1;
            this.rdbEmployee.TabStop = true;
            this.rdbEmployee.Text = "Employee";
            this.rdbEmployee.UseVisualStyleBackColor = true;
            // 
            // rdbMachine
            // 
            this.rdbMachine.AutoSize = true;
            this.rdbMachine.Location = new System.Drawing.Point(427, 133);
            this.rdbMachine.Name = "rdbMachine";
            this.rdbMachine.Size = new System.Drawing.Size(66, 17);
            this.rdbMachine.TabIndex = 2;
            this.rdbMachine.TabStop = true;
            this.rdbMachine.Text = "Machine";
            this.rdbMachine.UseVisualStyleBackColor = true;
            // 
            // btnProcced
            // 
            this.btnProcced.Location = new System.Drawing.Point(331, 195);
            this.btnProcced.Name = "btnProcced";
            this.btnProcced.Size = new System.Drawing.Size(75, 23);
            this.btnProcced.TabIndex = 3;
            this.btnProcced.Text = "Procced";
            this.btnProcced.UseVisualStyleBackColor = true;
            this.btnProcced.Click += new System.EventHandler(this.btnProcced_Click);
            // 
            // TSM_Activities
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnProcced);
            this.Controls.Add(this.rdbMachine);
            this.Controls.Add(this.rdbEmployee);
            this.Controls.Add(this.lblHeading);
            this.Name = "TSM_Activities";
            this.Text = "TSM_Activities";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblHeading;
        private System.Windows.Forms.RadioButton rdbEmployee;
        private System.Windows.Forms.RadioButton rdbMachine;
        private System.Windows.Forms.Button btnProcced;
    }
}