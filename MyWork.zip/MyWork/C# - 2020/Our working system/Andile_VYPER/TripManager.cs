﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Andile_VYPER
{
    public partial class TripManager : Form
    {
        SqlConnection connecting = new SqlConnection(@"Data Source=STHE-ONP63U3\MSSQLSERVER01;Initial Catalog=WILL;Integrated Security=True");
        public TripManager()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                connecting.Open();
                string query = "SELECT * FROM Trip_MANAGER WHERE userName =@UserName AND pass =@Password";

                SqlCommand cmd = new SqlCommand(query, connecting);

                cmd.Parameters.AddWithValue("@UserName", txtUserName.Text);
                cmd.Parameters.AddWithValue("@Password", txtPassword.Text);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Welcome" + txtUserName.Text);

                connecting.Close();

                TPM_Activities trip = new TPM_Activities();

                trip.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            this.Hide();

            TripManager TPM = new TripManager();

            TPM.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Regular myReg = new Regular();
            myReg.Show();
        }
    }
}
