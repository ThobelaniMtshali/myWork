﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace Andile_VYPER
{
    public partial class Regular : Form
    {
        public Regular()
        {
            InitializeComponent();
        }

        private void btnProcced_Click(object sender, EventArgs e)
        {
            if(rdb_VehicleAdmin.Checked)
            {
                this.Hide();
                VehicleAdmin VA = new VehicleAdmin();
                VA.Show();
            }
            else if(rdb_TripManager.Checked)
            {
                this.Hide();
                TripManager TPM = new TripManager();
                TPM.Show();
            }
            else if(rdb_ServiceManager.Checked)
            {
                this.Hide();
                ServiceManagement SM = new ServiceManagement();
                SM.Show();
            }
            else if(rdbTimesheetManager.Checked)
            {
                this.Hide();
                TimesheetManager TSM = new TimesheetManager();
                TSM.Show();
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Welcome myWelcome = new Welcome();

            myWelcome.Show();
        }
    }
}
