﻿namespace Andile_VYPER
{
    partial class Regular
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblHeading = new System.Windows.Forms.Label();
            this.rdb_VehicleAdmin = new System.Windows.Forms.RadioButton();
            this.rdb_TripManager = new System.Windows.Forms.RadioButton();
            this.rdb_ServiceManager = new System.Windows.Forms.RadioButton();
            this.rdbTimesheetManager = new System.Windows.Forms.RadioButton();
            this.btnProcced = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblHeading
            // 
            this.lblHeading.AutoSize = true;
            this.lblHeading.Font = new System.Drawing.Font("Modern No. 20", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeading.Location = new System.Drawing.Point(273, 33);
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.Size = new System.Drawing.Size(261, 50);
            this.lblHeading.TabIndex = 7;
            this.lblHeading.Text = "Department";
            // 
            // rdb_VehicleAdmin
            // 
            this.rdb_VehicleAdmin.AutoSize = true;
            this.rdb_VehicleAdmin.Location = new System.Drawing.Point(172, 100);
            this.rdb_VehicleAdmin.Name = "rdb_VehicleAdmin";
            this.rdb_VehicleAdmin.Size = new System.Drawing.Size(123, 17);
            this.rdb_VehicleAdmin.TabIndex = 8;
            this.rdb_VehicleAdmin.TabStop = true;
            this.rdb_VehicleAdmin.Text = "Vehicle Administrator";
            this.rdb_VehicleAdmin.UseVisualStyleBackColor = true;
            // 
            // rdb_TripManager
            // 
            this.rdb_TripManager.AutoSize = true;
            this.rdb_TripManager.Location = new System.Drawing.Point(301, 100);
            this.rdb_TripManager.Name = "rdb_TripManager";
            this.rdb_TripManager.Size = new System.Drawing.Size(88, 17);
            this.rdb_TripManager.TabIndex = 9;
            this.rdb_TripManager.TabStop = true;
            this.rdb_TripManager.Text = "Trip Manager";
            this.rdb_TripManager.UseVisualStyleBackColor = true;
            // 
            // rdb_ServiceManager
            // 
            this.rdb_ServiceManager.AutoSize = true;
            this.rdb_ServiceManager.Location = new System.Drawing.Point(395, 100);
            this.rdb_ServiceManager.Name = "rdb_ServiceManager";
            this.rdb_ServiceManager.Size = new System.Drawing.Size(106, 17);
            this.rdb_ServiceManager.TabIndex = 10;
            this.rdb_ServiceManager.TabStop = true;
            this.rdb_ServiceManager.Text = "Service Manager";
            this.rdb_ServiceManager.UseVisualStyleBackColor = true;
            // 
            // rdbTimesheetManager
            // 
            this.rdbTimesheetManager.AutoSize = true;
            this.rdbTimesheetManager.Location = new System.Drawing.Point(507, 100);
            this.rdbTimesheetManager.Name = "rdbTimesheetManager";
            this.rdbTimesheetManager.Size = new System.Drawing.Size(119, 17);
            this.rdbTimesheetManager.TabIndex = 11;
            this.rdbTimesheetManager.TabStop = true;
            this.rdbTimesheetManager.Text = "Timesheet Manager";
            this.rdbTimesheetManager.UseVisualStyleBackColor = true;
            // 
            // btnProcced
            // 
            this.btnProcced.Location = new System.Drawing.Point(395, 177);
            this.btnProcced.Name = "btnProcced";
            this.btnProcced.Size = new System.Drawing.Size(75, 23);
            this.btnProcced.TabIndex = 12;
            this.btnProcced.Text = "Procced";
            this.btnProcced.UseVisualStyleBackColor = true;
            this.btnProcced.Click += new System.EventHandler(this.btnProcced_Click);
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(301, 177);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 13;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // Regular
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnProcced);
            this.Controls.Add(this.rdbTimesheetManager);
            this.Controls.Add(this.rdb_ServiceManager);
            this.Controls.Add(this.rdb_TripManager);
            this.Controls.Add(this.rdb_VehicleAdmin);
            this.Controls.Add(this.lblHeading);
            this.Name = "Regular";
            this.Text = "Regular";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblHeading;
        private System.Windows.Forms.RadioButton rdb_VehicleAdmin;
        private System.Windows.Forms.RadioButton rdb_TripManager;
        private System.Windows.Forms.RadioButton rdb_ServiceManager;
        private System.Windows.Forms.RadioButton rdbTimesheetManager;
        private System.Windows.Forms.Button btnProcced;
        private System.Windows.Forms.Button btnBack;
    }
}