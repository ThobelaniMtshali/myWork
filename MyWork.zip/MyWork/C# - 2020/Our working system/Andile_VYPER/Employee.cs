﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Andile_VYPER
{
    public partial class Employee : Form
    {
        SqlConnection connecting = new SqlConnection(@"Data Source=STHE-ONP63U3\MSSQLSERVER01;Initial Catalog=WILL;Integrated Security=True");
        public Employee()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                connecting.Open();

                string query = "INSERT INTO EMPLOYEES VALUES ('" + txtEmployeeName.Text + "','" + txtHours.Text + "')";

                SqlCommand cmd = new SqlCommand(query,connecting);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Stored");

                connecting.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Dispose();
        }
    }
}
