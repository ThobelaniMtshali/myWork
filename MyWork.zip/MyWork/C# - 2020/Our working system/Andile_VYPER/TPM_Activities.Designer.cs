﻿namespace Andile_VYPER
{
    partial class TPM_Activities
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblHeading = new System.Windows.Forms.Label();
            this.lblVehiclePlate = new System.Windows.Forms.Label();
            this.lblDestination = new System.Windows.Forms.Label();
            this.lblKM = new System.Windows.Forms.Label();
            this.txtVehiclePlate = new System.Windows.Forms.TextBox();
            this.txtDestination = new System.Windows.Forms.TextBox();
            this.txtKMH = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblHeading
            // 
            this.lblHeading.AutoSize = true;
            this.lblHeading.Font = new System.Drawing.Font("Modern No. 20", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeading.Location = new System.Drawing.Point(335, 51);
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.Size = new System.Drawing.Size(108, 50);
            this.lblHeading.TabIndex = 0;
            this.lblHeading.Text = "Trip";
            // 
            // lblVehiclePlate
            // 
            this.lblVehiclePlate.AutoSize = true;
            this.lblVehiclePlate.Location = new System.Drawing.Point(266, 117);
            this.lblVehiclePlate.Name = "lblVehiclePlate";
            this.lblVehiclePlate.Size = new System.Drawing.Size(71, 13);
            this.lblVehiclePlate.TabIndex = 1;
            this.lblVehiclePlate.Text = "Number Plate";
            // 
            // lblDestination
            // 
            this.lblDestination.AutoSize = true;
            this.lblDestination.Location = new System.Drawing.Point(266, 154);
            this.lblDestination.Name = "lblDestination";
            this.lblDestination.Size = new System.Drawing.Size(60, 13);
            this.lblDestination.TabIndex = 2;
            this.lblDestination.Text = "Destination";
            // 
            // lblKM
            // 
            this.lblKM.AutoSize = true;
            this.lblKM.Location = new System.Drawing.Point(266, 200);
            this.lblKM.Name = "lblKM";
            this.lblKM.Size = new System.Drawing.Size(36, 13);
            this.lblKM.TabIndex = 3;
            this.lblKM.Text = "KM/H";
            // 
            // txtVehiclePlate
            // 
            this.txtVehiclePlate.Location = new System.Drawing.Point(344, 117);
            this.txtVehiclePlate.Name = "txtVehiclePlate";
            this.txtVehiclePlate.Size = new System.Drawing.Size(156, 20);
            this.txtVehiclePlate.TabIndex = 4;
            // 
            // txtDestination
            // 
            this.txtDestination.Location = new System.Drawing.Point(344, 154);
            this.txtDestination.Name = "txtDestination";
            this.txtDestination.Size = new System.Drawing.Size(156, 20);
            this.txtDestination.TabIndex = 5;
            // 
            // txtKMH
            // 
            this.txtKMH.Location = new System.Drawing.Point(344, 200);
            this.txtKMH.Name = "txtKMH";
            this.txtKMH.Size = new System.Drawing.Size(156, 20);
            this.txtKMH.TabIndex = 6;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(344, 238);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 7;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(425, 238);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 8;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // TPM_Activities
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtKMH);
            this.Controls.Add(this.txtDestination);
            this.Controls.Add(this.txtVehiclePlate);
            this.Controls.Add(this.lblKM);
            this.Controls.Add(this.lblDestination);
            this.Controls.Add(this.lblVehiclePlate);
            this.Controls.Add(this.lblHeading);
            this.Name = "TPM_Activities";
            this.Text = "TPM_Activities";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblHeading;
        private System.Windows.Forms.Label lblVehiclePlate;
        private System.Windows.Forms.Label lblDestination;
        private System.Windows.Forms.Label lblKM;
        private System.Windows.Forms.TextBox txtVehiclePlate;
        private System.Windows.Forms.TextBox txtDestination;
        private System.Windows.Forms.TextBox txtKMH;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnExit;
    }
}