﻿namespace Andile_VYPER
{
    partial class Welcome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblHeading = new System.Windows.Forms.Label();
            this.rdbOfficeManagement = new System.Windows.Forms.RadioButton();
            this.rdbRegularEmployee = new System.Windows.Forms.RadioButton();
            this.btnProcced = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblHeading
            // 
            this.lblHeading.AutoSize = true;
            this.lblHeading.Font = new System.Drawing.Font("Modern No. 20", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeading.Location = new System.Drawing.Point(61, 63);
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.Size = new System.Drawing.Size(727, 38);
            this.lblHeading.TabIndex = 0;
            this.lblHeading.Text = "Welcome to our Cargo Fleet (Tracking System)";
            this.lblHeading.Click += new System.EventHandler(this.label1_Click);
            // 
            // rdbOfficeManagement
            // 
            this.rdbOfficeManagement.AutoSize = true;
            this.rdbOfficeManagement.Location = new System.Drawing.Point(266, 144);
            this.rdbOfficeManagement.Name = "rdbOfficeManagement";
            this.rdbOfficeManagement.Size = new System.Drawing.Size(118, 17);
            this.rdbOfficeManagement.TabIndex = 1;
            this.rdbOfficeManagement.TabStop = true;
            this.rdbOfficeManagement.Text = "Office Management";
            this.rdbOfficeManagement.UseVisualStyleBackColor = true;
            // 
            // rdbRegularEmployee
            // 
            this.rdbRegularEmployee.AutoSize = true;
            this.rdbRegularEmployee.Location = new System.Drawing.Point(430, 144);
            this.rdbRegularEmployee.Name = "rdbRegularEmployee";
            this.rdbRegularEmployee.Size = new System.Drawing.Size(105, 17);
            this.rdbRegularEmployee.TabIndex = 2;
            this.rdbRegularEmployee.TabStop = true;
            this.rdbRegularEmployee.Text = "Regular Emplyee";
            this.rdbRegularEmployee.UseVisualStyleBackColor = true;
            // 
            // btnProcced
            // 
            this.btnProcced.Location = new System.Drawing.Point(354, 207);
            this.btnProcced.Name = "btnProcced";
            this.btnProcced.Size = new System.Drawing.Size(75, 23);
            this.btnProcced.TabIndex = 3;
            this.btnProcced.Text = "Procced";
            this.btnProcced.UseVisualStyleBackColor = true;
            this.btnProcced.Click += new System.EventHandler(this.btnProcced_Click);
            // 
            // Welcome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnProcced);
            this.Controls.Add(this.rdbRegularEmployee);
            this.Controls.Add(this.rdbOfficeManagement);
            this.Controls.Add(this.lblHeading);
            this.Name = "Welcome";
            this.Text = "Welcome";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblHeading;
        private System.Windows.Forms.RadioButton rdbOfficeManagement;
        private System.Windows.Forms.RadioButton rdbRegularEmployee;
        private System.Windows.Forms.Button btnProcced;
    }
}

